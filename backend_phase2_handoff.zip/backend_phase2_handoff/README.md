# Football Player Intelligence Platform — Phase 2 Backend Handoff

## What this package is

This is a complete documentation snapshot of the backend data/ingestion
layer for a Football Player Intelligence Platform, at the end of
**Phase 2 (all sub-phases 2.1–2.6c)**. It was produced by an AI coding
session that does not persist state between conversations — this
package is the memory transfer mechanism to whatever conversation
continues the work next.

## Phase 2 is complete

Everything described in this package has been **implemented, tested,
and verified against real data**, not just designed. Read
`CURRENT_STATUS.md` first for the exact state, then `ARCHITECTURE.md`
for how the pieces fit together.

## What has been implemented (one-line summary)

A provider-based ingestion pipeline that pulls player data from EA FC26
(real, 16,107 players), a CC0 transfermarkt-derived dataset (currently a
small labeled sample fixture — see `KNOWN_ISSUES.md`), and Wikidata
(also a small labeled sample fixture), validates and normalizes each
source independently, matches identities across sources with a scored,
confidence-thresholded, non-destructive engine, persists everything to
a DuckDB database with full source lineage, queues ambiguous matches
for human review, and reports on data coverage/quality — all
orchestrated by one reproducible command
(`python3 scripts/run_ingestion.py`).

## How the next conversation should use this package

1. Read `CURRENT_STATUS.md` — what's done, what test count to expect,
   what the recommended next step is.
2. Read `ARCHITECTURE.md` and `DATA_FLOW.md` to understand the shape of
   the system before touching code.
3. Read `DATABASE_SCHEMA.md` before writing any query — several tables
   have non-obvious constraints (see especially the `players.wikidata_id`
   note) that will cause a confusing runtime error if not understood
   first.
4. Read `KNOWN_ISSUES.md` before assuming something is broken — several
   apparent oddities (e.g. very low "lineage coverage" percentages) are
   expected given the current sample-fixture data volume, not bugs.
5. Read `NEXT_PHASE.md` for the recommended next step (API/service
   layer) and why it's recommended before frontend work.
6. The actual source code is NOT included in this package (see below) —
   this package is orientation and decision-history documentation, to
   be read alongside the real codebase.

## What is NOT included in this package

- **No source code.** This package assumes the actual project files
  (the `football-intel/` directory: `ingestion/`, `matching/`,
  `reporting/`, `scripts/`, `config/`, `db/`, `tests/`, `data/`) persist
  independently — e.g. committed to the user's own Git repository. This
  package documents that code; it does not replace it.
- **No raw data files.** The real EA FC26 dataset (16,107 players) and
  the sample fixtures for transfermarkt_dataset and wikidata are
  described here but not included.
- **No conversation history.** This package is a summary of the final
  implemented state and the technical decisions/bugs that shaped it —
  not a transcript.
- **No Phase 3+ work.** No API, service layer, ML integration, frontend,
  or UI code exists yet. See `NEXT_PHASE.md`.
