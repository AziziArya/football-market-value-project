#!/usr/bin/env python3
"""Consolidated mutation checks for the completed steps (G9, 4.1, 4.2, 4.3, G14).

Usage (from anywhere):  python3 mutation_checks.py /path/to/football_intel_backend_phase2/project [batch]
batch = 1, 2 or 3 (default: all). Each mutation edits ONE source file, runs a targeted subset of the tests with -x,
and restores the file afterwards. A mutation is CAUGHT when pytest reports a FAILED test (a crash/collection error is
reported as INVALID, not as caught). Exit code 1 if any valid mutation survives. The project is left unchanged."""
import subprocess, sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
ONLY = int(sys.argv[2]) if len(sys.argv) > 2 else None
T = "tests/test_api/"
M = [  # (batch, step, description, file, old, new, tests)
 (1, "G9", "ingestion: identity-field idempotency guard removed", "ingestion/loader.py", "    if not fields:\n        return []\n    sources = sorted({f.source for f in fields})", "    return fields\n    sources = sorted({f.source for f in fields})", ["tests/test_idempotency"]),
 (1, "G9", "matching: unchanged results are re-appended", "scripts/run_ingestion.py", "changed = drop_unchanged_match_results(con, results)", "changed = results", ["tests/test_idempotency"]),
 (1, "G9", "wikidata fixture version depends on the run date again", "ingestion/providers/wikidata.py", 'dataset_version = "fixture:" + hashlib.sha256(self.fixture_path.read_bytes()).hexdigest()[:12]', 'dataset_version = f"fixture:{fetched_at.date().isoformat()}"', ["tests/test_idempotency"]),
 (1, "4.1", "connection opened read-write", "api/repositories/database.py", "read_only=True", "read_only=False", [T + "test_architecture_api.py"]),
 (1, "4.1", "router imports a repository", "api/routers/health.py", "from fastapi import APIRouter, Request", "from fastapi import APIRouter, Request\nfrom api.repositories import catalog_repository", [T + "test_architecture_api.py"]),
 (1, "4.1", "domain imports the ingestion pipeline", "api/domain/normalize.py", "import unicodedata\n", "import unicodedata\nfrom ingestion import loader\n", [T + "test_architecture_api.py"]),
 (1, "4.1", "ML model flagged as integrated", "api/domain/source_registry.py", "MODEL_INTEGRATED = False", "MODEL_INTEGRATED = True", [T + "test_endpoints.py"]),
 (1, "4.1", "wikidata presented as REAL_FULL", "api/domain/source_registry.py", 'SourceInfo("wikidata", FreshnessRole.ENRICHMENT, DataOrigin.SAMPLE_FIXTURE)', 'SourceInfo("wikidata", FreshnessRole.ENRICHMENT, DataOrigin.REAL_FULL)', [T + "test_domain.py"]),
 (1, "4.1", "is_live reported true", "api/services/freshness_service.py", "is_live=is_live(info.name)", "is_live=True", [T + "test_endpoints.py"]),
 (1, "4.1", "startup no longer checks the ML columns (fail-open)", "api/services/integrity_service.py", "    if ml_in_use:", "    if False:", [T + "test_integrity.py"]),
 (1, "G14", "startup no longer checks overall_rating/potential", "api/services/integrity_service.py", "r.overall_rating is None or r.potential is None", "False", [T + "test_integrity.py"]),
 (2, "4.2", "alias reported when merely equal", "api/domain/search.py", "QUALITY_RANK[best_alias_quality] < QUALITY_RANK[quality]):", "QUALITY_RANK[best_alias_quality] <= QUALITY_RANK[quality]):", [T + "test_search_domain.py"]),
 (2, "4.2", "no ea-id tie-break in relevance order", "api/domain/search.py", "key=lambda m: (QUALITY_RANK[m[1]], -m[0].overall, m[0].ea_fc26_id))", "key=lambda m: (QUALITY_RANK[m[1]], -m[0].overall))", [T + "test_search_domain.py"]),
 (2, "4.2", "confidence exposed for AMBIGUOUS/UNMATCHED", "api/domain/link_rules.py", "        return st, None, None", "        return st, confidence, matched_on", [T + "test_search_endpoint.py"]),
 (2, "4.2", "filters case-sensitive", "api/services/search_service.py", "return value.casefold() if value else None", "return value if value else None", [T + "test_search_endpoint.py"]),
 (2, "4.2", "unknown query parameters ignored", "api/routers/search.py", "    if unknown:", "    if False:", [T + "test_search_endpoint.py"]),
 (2, "4.2", "next_offset off by one", "api/services/search_service.py", "next_offset=end if end < result.total else None", "next_offset=end if end <= result.total else None", [T + "test_search_endpoint.py"]),
 (2, "4.2", "N+1: market value queried per player", "api/services/player_summary.py", "    return CanonicalDetails(player_detail_repository.latest_market_values(cur, uids),", "    mv = {}\n    for u in uids:\n        mv.update(player_detail_repository.latest_market_values(cur, [u]))\n    return CanonicalDetails(mv,", [T + "test_search_endpoint.py"]),
 (2, "4.2", "non-Wikidata images allowed", "api/domain/source_registry.py", 'IMAGE_SOURCES: tuple[str, ...] = ("wikidata",)', 'IMAGE_SOURCES: tuple[str, ...] = ("wikidata", "sofifa")', [T + "test_search_endpoint.py"]),
 (2, "4.2", "transfermarkt id shown regardless of link status", "api/services/player_summary.py", "transfermarkt_id=row.transfermarkt_id if tm.status in LINKED else None", "transfermarkt_id=row.transfermarkt_id", [T + "test_search_endpoint.py"]),
 (2, "4.2", "accent folding table emptied", "api/domain/normalize.py", '_FOLD = {"ø": "o", "ł": "l", "ı": "i", "æ": "ae", "œ": "oe", "ð": "d", "þ": "th", "đ": "d", "ħ": "h"}', "_FOLD = {}", [T + "test_search_domain.py"]),
 (3, "4.3", "p:<uuid> accepted as an id", "api/domain/player_id.py", 'PLAYER_ID_PATTERN = r"^ea:(0|[1-9][0-9]{0,8})$"', 'PLAYER_ID_PATTERN = r"^(ea:(0|[1-9][0-9]{0,8})|p:[0-9a-f-]{36})$"', [T + "test_player_endpoint.py"]),
 (3, "4.3", "match instead of fullmatch (trailing newline accepted)", "api/domain/player_id.py", "_RE.fullmatch(raw)", "_RE.match(raw)", [T + "test_player_endpoint.py"]),
 (3, "4.3", "leading zeros accepted", "api/domain/player_id.py", "(0|[1-9][0-9]{0,8})", "[0-9]{1,9}", [T + "test_player_endpoint.py"]),
 (3, "4.3", "non-ASCII digits accepted", "api/domain/player_id.py", 'PLAYER_ID_PATTERN = r"^ea:(0|[1-9][0-9]{0,8})$"', 'PLAYER_ID_PATTERN = r"^ea:(0|[1-9]\\d{0,8})$"', [T + "test_player_endpoint.py"]),
 (3, "4.3", "rejected id reflected through `instance`", "api/errors.py", "redact_instance=True", "redact_instance=False", [T + "test_player_endpoint.py"]),
 (3, "4.3", "unknown id answers 400 instead of 404", "api/services/player_service.py", "raise player_not_found(raw_player_id)", "raise invalid_player_id()", [T + "test_player_endpoint.py"]),
 (3, "4.3", "id route registered before /players/search", "api/app.py", '    app.include_router(search.router, prefix=API_BASE_PATH)    # before /players/{player_id}: "search" is not an id\n    app.include_router(player.router, prefix=API_BASE_PATH)', '    app.include_router(player.router, prefix=API_BASE_PATH)\n    app.include_router(search.router, prefix=API_BASE_PATH)', [T + "test_player_endpoint.py"]),
 (3, "4.3", "wikidata never listed in provenance", "api/services/player_service.py", 'if wikidata_row is not None or links["wikidata"].status in LINKED or summary.image is not None:', "if False:", [T + "test_player_endpoint.py"]),
 (3, "4.3", "EA-only profile opens the database", "api/services/player_service.py", "if row.entity_kind is EntityKind.CANONICAL:        # EA-only: no database access at all", "if True:", [T + "test_player_endpoint.py"]),
 (3, "4.3", "public id built from the internal uuid", "api/services/player_summary.py", 'id=f"ea:{row.ea_fc26_id}"', 'id=(f"p:{uid}" if uid else f"ea:{row.ea_fc26_id}")', [T + "test_player_endpoint.py"]),
 (3, "4.3", "contains_sample_data always true", "api/services/player_service.py", "contains_sample_data=player_summary.contains_sample_data(summary)", "contains_sample_data=True", [T + "test_player_endpoint.py"]),
]
results, survivors = [], 0
for batch, step, desc, rel, old, new, tests in M:
    if ONLY and batch != ONLY:
        continue
    f = ROOT / rel
    original = f.read_bytes()
    text = original.decode("utf-8")
    assert old in text, f"mutation target not found (code changed?): {rel}: {old[:60]!r}"
    f.write_text(text.replace(old, new, 1), encoding="utf-8")
    try:
        r = subprocess.run([sys.executable, "-m", "pytest", *tests, "-q", "-x", "-p", "no:cacheprovider"], cwd=ROOT, capture_output=True, text=True, timeout=300)
        out = r.stdout + r.stderr
        failed = [l for l in out.splitlines() if l.startswith("FAILED")]
        status = "CAUGHT" if failed else ("INVALID(crash)" if r.returncode != 0 else "SURVIVED")
        by = failed[0].split("::")[-1].split(" ")[0][:70] if failed else ""
    finally:
        f.write_bytes(original)
    survivors += status != "CAUGHT"
    print(f"[{status:14s}] {step:4s} {desc:58s} {by}", flush=True)
print(f"\n{sum(1 for _ in results) or ''}done; not-caught: {survivors}")
sys.exit(1 if survivors else 0)
