"""The generated OpenAPI of the running app must conform to api_contract/openapi.json (contract wins)."""
import pytest

from api import API_BASE_PATH

IMPLEMENTED = {"/health": "getHealth", "/data-freshness": "getDataFreshness", "/players/search": "searchPlayers"}


@pytest.fixture
def generated(small_db, make_client):
    return make_client(small_db, enable_docs=True).get("/openapi.json").json()


def test_paths_and_operation_ids_match_the_contract(generated, contract):
    assert {p: item["get"]["operationId"] for p, item in generated["paths"].items()} == \
           {API_BASE_PATH + p: oid for p, oid in IMPLEMENTED.items()}
    for p, oid in IMPLEMENTED.items():
        assert contract["paths"][p]["get"]["operationId"] == oid
        assert list(generated["paths"][API_BASE_PATH + p]) == ["get"]          # GET only


def test_success_response_schemas_are_the_contract_ones(generated, contract):
    for p in IMPLEMENTED:
        want = contract["paths"][p]["get"]["responses"]["200"]["content"]["application/json"]["schema"]["$ref"].split("/")[-1]
        got = generated["paths"][API_BASE_PATH + p]["get"]["responses"]["200"]["content"]["application/json"]["schema"]["$ref"].split("/")[-1]
        assert got == want
        assert {"503", "500"} <= set(generated["paths"][API_BASE_PATH + p]["get"]["responses"])
        want = {"200", "400", "503", "500"} if p == "/players/search" else {"200", "503", "500"}
        assert set(contract["paths"][p]["get"]["responses"]) == want


@pytest.mark.parametrize("name", ["HealthResponse", "DataFreshnessResponse", "SourceFreshness", "ResponseMeta", "Problem", "ProblemError"])
def test_schema_properties_match_the_contract(generated, contract, name):
    got, want = generated["components"]["schemas"][name], contract["components"]["schemas"][name]
    assert set(got["properties"]) == set(want["properties"])
    assert set(got.get("required", [])) <= set(want["required"] if "required" in want else [])     # we never require more than the contract
    assert got.get("additionalProperties") is False                                                 # extra fields can never leak


@pytest.mark.parametrize("name", ["FreshnessRole", "Availability", "DataOrigin"])
def test_generated_enums_equal_contract_enums(generated, contract, name):
    assert generated["components"]["schemas"][name]["enum"] == contract["components"]["schemas"][name]["enum"]


def test_is_live_is_a_constant_false_in_both(generated, contract):
    assert contract["components"]["schemas"]["SourceFreshness"]["properties"]["is_live"]["enum"] == [False]
    assert generated["components"]["schemas"]["SourceFreshness"]["properties"]["is_live"]["const"] is False


def test_contract_x_status_of_implemented_paths(contract):
    # nothing implemented in 4.1 may be a PLANNED/SCHEMA_ONLY operation
    for p in IMPLEMENTED:
        assert contract["paths"][p]["get"]["x-status"] == "IMPLEMENTABLE_TODAY"
